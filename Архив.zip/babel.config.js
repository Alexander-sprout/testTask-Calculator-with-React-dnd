module.exports = {
    presets: ['@babel/preset-react', '@babel/preset-typescript'],
    plugins: [
        '@babel/plugin-proposal-class-properties',
        '@babel/plugin-transform-typescript',
        '@babel/plugin-transform-runtime',
    ]
}