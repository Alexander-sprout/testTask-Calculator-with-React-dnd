# Sanya Boilerplate

## Перед запуском
Создайте файл .env по образцу .env.example


## Версии пакетов

- React 18
- ReactDom 18

## Команды запуска

- `npm install`
- `npm start` - запустить для разработки