import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export type UiType = 'result' | 'operations' | 'numbers' | 'equal-sign'
export type UiItem = { type: UiType }

const TooggleSlice = createSlice({
    name: 'toggle',
    initialState: {
        executeCalc: false,
        defaultList: [
            {
                type: 'result',
            },
            {
                type: 'operations',
            },
            {
                type: 'numbers',
            },
            {
                type: 'equal-sign',
            }
        ] as UiItem[],
        uiList: [] as UiItem[],
    },
    reducers: {
        moveToUIList: (state, { payload }: PayloadAction<UiType>) => {
            console.log(payload)
            console.log(payload)
            console.log(payload)
            state.defaultList = state.defaultList.filter(({ type }) => type !== payload)
            state.uiList = [...state.uiList, { type: payload }]
        },
        moveToDefaultList: (state, { payload }: PayloadAction<UiType>) => {
            console.log(payload)
            console.log(payload)
            console.log(payload)
            state.uiList = state.uiList.filter(({ type }) => type !== payload)
            state.defaultList = [...state.defaultList, { type: payload }]
        },
        constructor: ({ executeCalc }) => {
            executeCalc = false
            console.log('constructor vagin')
        },
        calculator: ({ executeCalc }) => {
            executeCalc = true
            console.log('calculator soskov')
        }
    }
})

export default TooggleSlice.reducer

export const { constructor, calculator, moveToDefaultList, moveToUIList } = TooggleSlice.actions