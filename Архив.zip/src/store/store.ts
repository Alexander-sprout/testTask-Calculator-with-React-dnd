import { configureStore } from "@reduxjs/toolkit";
import { useDispatch } from "react-redux";
import calc from './CalcReduer'
import toggle from './ToggleReducer'


export const store = configureStore({
    reducer: { calc, toggle }
})



export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch
export const useAppDispatch: () => AppDispatch = useDispatch