import { createSlice, PayloadAction } from "@reduxjs/toolkit";



const calcSlice = createSlice({
    name: 'calc',
    initialState: {
        result: '0',
        operation: ''
    },
    reducers: {
        defineOperation: (state, action) => { state.operation = action.payload },
        joinNumbers: ({ result }, action: PayloadAction<string>) => {
            console.log(result)
            console.log(typeof result)
            console.log(result.includes('.'))
            if (result === '0' && action.payload !== '.') {
                result = action.payload
                console.log(result)
                console.log('я переписал пенисом в рот. Я политик')
            }
            if (result.includes('.') && action.payload !== '.') {
                result += action.payload.toString()
            }
            else {
                result += action.payload.toString()
            }
        },
    }
})


export default calcSlice.reducer


export const { defineOperation, joinNumbers } = calcSlice.actions

// joinNumbers: (state, action) => {
//     state.result === 0 && action.payload !== '.'
//     ? state.result = action.payload : state.result += action.payload.toString()
// },