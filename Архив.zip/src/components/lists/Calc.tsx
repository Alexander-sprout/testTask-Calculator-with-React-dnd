import React from 'react'
import styled from 'styled-components'
import { useSelector } from 'react-redux'

import {
    Display,
    GetResult,
    Numbers,
    Operations
} from '../../components/calc-elements'
import { RootState, useAppDispatch } from '../../store/store'
import { useDrop } from 'react-dnd'
import { moveToDefaultList, UiItem } from '../../store/ToggleReducer'


export const Calc = () => {
    const defaultList = useSelector((state: RootState) => state.toggle.defaultList)
    const dispatch = useAppDispatch()
    const [{ isOver }, dropRef] = useDrop(
        () => ({
            accept: 'KEYBOARD',
            collect: (monitor) => ({
                isOver: monitor.isOver(),
            }),
            drop: (item) => {
                console.log(item)
                // dispatch(moveToDefaultList((item as UiItem).type))
            },
        }),
        [dispatch]
    );
    return (
        <Container ref={dropRef} style={{ backgroundColor: isOver ? '#F0F9FF' : 'white' }}>
            {/* {defaultList.map(({ type }) => (
                <div key={type}>
                    {type === 'result' && <Display />}
                    {type === 'operations' && <Operations />}
                    {type === 'numbers' && <Numbers />}
                    {type === 'equal-sign' && <GetResult />}
                </div>
            ))} */}
            <Display />
            <Operations />
            <Numbers />
            <GetResult />
        </Container>
    )
}

const Container = styled.div`
    width:240px;
`