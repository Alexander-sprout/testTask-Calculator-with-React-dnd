import React from 'react'
import { useDrop } from 'react-dnd'
import styled from 'styled-components'

import { MdOutlineAddPhotoAlternate } from 'react-icons/md'
import { useDispatch, useSelector } from 'react-redux'
import { RootState } from '../../store/store'
import { Display, GetResult, Numbers, Operations } from '../../components/calc-elements'
import { moveToUIList, UiItem } from '../../store/ToggleReducer'

export const CalcExecute = () => {
    const uiList = useSelector((store: RootState) => store.toggle.uiList)
    const dispatch = useDispatch()
    const [{ canDrop, isOver }, dropRef] = useDrop(
        () => ({
            accept: 'KEYBOARD',
            collect: (monitor) => ({
                isOver: monitor.isOver(),
                canDrop: monitor.canDrop(),
            }),
            drop: (item, monitor) => {
                dispatch(moveToUIList((item as UiItem).type))
            },
        }),
        [dispatch]
    );

    return (
        <Wrapper ref={dropRef} style={{ backgroundColor: isOver ? '#F0F9FF' : 'white' }}>
            {uiList.length === 0
                ? (
                    <EmptyContainer>
                        <Placeholder>
                            <MdOutlineAddPhotoAlternate size={20} />
                            <FirstText>
                                Перетащите сюда
                            </FirstText>
                            <SecondText>
                                Любой элемент
                            </SecondText>
                            <SecondText>
                                из левой панели
                            </SecondText>
                        </Placeholder>
                    </EmptyContainer>)
                : (
                    <Container>
                        {uiList.map(({ type }) => (
                            <div key={type}>
                                {type === 'result' && <Display />}
                                {type === 'operations' && <Operations />}
                                {type === 'numbers' && <Numbers />}
                                {type === 'equal-sign' && <GetResult />}
                            </div>
                        ))}
                    </Container>
                )
            }
        </Wrapper>
    )
}
const Wrapper = styled.div`
    display:flex;
    flex-direction:column;
`

const Container = styled.div`
    width:240px;
`


const EmptyContainer = styled.div`
    display:flex;
    flex-direction:column;
    border: 2px dashed #C4C4C4;
    border-radius: 6px;
    width:243px;
    height:448px;
`
const Placeholder = styled.div`
    display:flex;
    flex-direction:column;
    /* justify-content:center; */
    align-items:center;
    font-family:'inter';
    margin:auto;
`

const FirstText = styled.div`
    font-weight:500;
    color:#5D5FEF;
    font-size:14px;
`
const SecondText = styled.div`
    font-weight:400;
    font-size:12px;
`