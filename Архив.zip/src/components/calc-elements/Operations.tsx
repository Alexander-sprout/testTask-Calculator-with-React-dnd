import React from 'react'
import { useDrag } from 'react-dnd'
import styled from 'styled-components'

import { useAppDispatch } from '../../store/store'
import { operationArr } from '../../interfaces'
import { defineOperation } from '../../store/CalcReduer'


export const Operations = () => {
    const [{ opacity }, dragRef] = useDrag(
        () => ({
            type: 'KEYBOARD',
            item: {
                type: 'operations',
            },
            collect: (monitor) => ({
                opacity: monitor.isDragging() ? 0.5 : 1
            }),
        }),
        []
    )
    const dispatch = useAppDispatch()

    return (
        <Wrapper ref={dragRef} style={{ opacity }}>
            <Container>
                {operationArr.map((item, index) => <OperationButton key={index}
                    onClick={() => dispatch(defineOperation(item))}
                >
                    {item}</OperationButton>)}
            </Container>
        </Wrapper>
    )
}

const Container = styled.div`
    width:240px;
    height:56px;
    box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.06), 0px 4px 6px rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    display:flex;
    justify-content:space-between;
`

const Wrapper = styled.div`
display:flex;
flex-direction:row;
margin-bottom:10px;
`

const OperationButton = styled.button`
    width:52px;
    height:48px;
    margin:auto;
    font-family:'inter';
    font-weight:500;
    background-color:#ffffff;
    border: 1px solid #E2E3E5;
    border-radius:6px;
    font-size:14px;
`