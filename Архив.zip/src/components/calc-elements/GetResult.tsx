import React from 'react'
import { useDrag } from 'react-dnd'
import styled from 'styled-components'



export const GetResult = () => {
    const [{ opacity }, dragRef] = useDrag(
        () => ({
            type: 'KEYBOARD',
            item: { type: 'equal-sign' },
            collect: (monitor) => ({
                opacity: monitor.isDragging() ? 0.5 : 1
            })
        }),
        []
    )
    return (
        <Container ref={dragRef} style={{ opacity }}>
            <ResultButton>=</ResultButton>
        </Container>
    )
}

const ResultButton = styled.div`
display:flex;
justify-content:center;
align-items:center;
    width:232px;
    height:64px;
    background-color: #5D5FEF;
    border-radius: 6px;
    color:white;
    font-size:14px;
    font-family:'inter';
    font-weight:500;
`

const Container = styled.div`
    width:240px;
    height:72px;
    box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.06), 0px 4px 6px rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    display:flex;
    justify-content:center;
    align-items:center;
    margin-top:13px;
`