import React from 'react'
import { useDrag } from 'react-dnd'
import styled from 'styled-components'

import { useAppDispatch } from '../../store/store'
import { NumbersArr } from '../../interfaces'
import { joinNumbers } from '../../store/CalcReduer'

export const Numbers = () => {
    const dispatch = useAppDispatch()
    const [{ opacity }, dragRef] = useDrag(
        () => ({
            type: 'KEYBOARD',
            item: { type: 'numbers' },
            collect: (monitor) => ({
                opacity: monitor.isDragging() ? 0.5 : 1,
            })
        }),
        []
    )
    return (
        <Container ref={dragRef} style={{ opacity }}>
            {NumbersArr.map((item, index) => <NumButton key={index}
                onClick={() => dispatch(joinNumbers(item.toString()))}
            >{item}</NumButton>)}
            <NullButton onClick={() => dispatch(joinNumbers('0'))}>0</NullButton>
            <NumButton onClick={() => dispatch(joinNumbers('.'))}>,</NumButton>
        </Container>
    )
}

const Container = styled.div`
width:240px;
height:224px;
border-radius:4px;
box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.06), 0px 4px 6px rgba(0, 0, 0, 0.1);
display:flex;
flex-wrap: wrap;
justify-content:flex-start;
`

const NullButton = styled.button`
     width:152px;
    height:48px;
    margin:auto;
    font-family:'inter';
    font-weight:500;
    background-color:#ffffff;
    border: 1px solid #E2E3E5;
    border-radius:6px;
    font-size:14px;
`

const NumButton = styled.button`
    width:72px;
    height:48px;
    margin:auto;
    font-family:'inter';
    font-weight:500;
    background-color:#ffffff;
    border: 1px solid #E2E3E5;
    border-radius:6px;
    font-size:14px;
`