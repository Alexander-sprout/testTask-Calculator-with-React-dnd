import React from 'react'
import styled from 'styled-components'

import { useSelector } from 'react-redux'
import { RootState } from 'store/store'
import { useDrag } from 'react-dnd'

export const Display = () => {
    const result = useSelector((state: RootState) => state.calc.result)

    const [{ opacity }, dragRef] = useDrag(
        () => ({
            type: 'KEYBOARD',
            item: { type: 'result' },
            collect: (monitor) => ({
                opacity: monitor.isDragging() ? 0.5 : 1
            })
        }),
        []
    )
    return (
        <Wrapper ref={dragRef} style={{ opacity }}>
            <Container>
                <ViewResult>
                    {result.toString().replace('.', ',')}
                </ViewResult>
            </Container>
        </Wrapper>
    )
}

const Wrapper = styled.div`
display:flex;
justify-content:center;
align-items:center;
margin-bottom:13px;
    width:240px;
    height:60px;
    border-radius:4px;
    box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.06), 0px 4px 6px rgba(0, 0, 0, 0.1);
`

const Container = styled.div`
display:flex;
    width:232px;
    height:52px;
justify-content:flex-end;
align-items:center;
border-radius:6px;
background: #F3F4F6;
`

const ViewResult = styled.div`
    font-family:'inter';
    font-weight:800;
    padding:7px;
   font-size:36px;
`