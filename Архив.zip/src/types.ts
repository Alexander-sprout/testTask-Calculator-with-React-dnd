export type isCalcProps = {
    isCalc: boolean;
};